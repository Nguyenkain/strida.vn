<?php
set_time_limit(100000000);
include('includes.php');
include('functions.php');
include('html_dom.php');
?>